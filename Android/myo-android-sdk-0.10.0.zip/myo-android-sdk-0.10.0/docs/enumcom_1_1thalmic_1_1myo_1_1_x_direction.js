var enumcom_1_1thalmic_1_1myo_1_1_x_direction =
[
    [ "TOWARD_ELBOW", "enumcom_1_1thalmic_1_1myo_1_1_x_direction.html#a31256123de8c56262f133c4a13ab334e", null ],
    [ "TOWARD_WRIST", "enumcom_1_1thalmic_1_1myo_1_1_x_direction.html#ad6a4569d64bfcd0fdd546b6d2eebedec", null ],
    [ "UNKNOWN", "enumcom_1_1thalmic_1_1myo_1_1_x_direction.html#aa1d1805a940a3f98c6432d5c1109d671", null ]
];