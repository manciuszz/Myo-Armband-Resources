var annotated =
[
    [ "com", null, [
      [ "thalmic", null, [
        [ "myo", null, [
          [ "AbstractDeviceListener", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener" ],
          [ "Arm", "enumcom_1_1thalmic_1_1myo_1_1_arm.html", "enumcom_1_1thalmic_1_1myo_1_1_arm" ],
          [ "DeviceListener", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener" ],
          [ "FirmwareVersion", "classcom_1_1thalmic_1_1myo_1_1_firmware_version.html", "classcom_1_1thalmic_1_1myo_1_1_firmware_version" ],
          [ "Hub", "classcom_1_1thalmic_1_1myo_1_1_hub.html", "classcom_1_1thalmic_1_1myo_1_1_hub" ],
          [ "Myo", "classcom_1_1thalmic_1_1myo_1_1_myo.html", "classcom_1_1thalmic_1_1myo_1_1_myo" ],
          [ "Pose", "enumcom_1_1thalmic_1_1myo_1_1_pose.html", "enumcom_1_1thalmic_1_1myo_1_1_pose" ],
          [ "Quaternion", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html", "classcom_1_1thalmic_1_1myo_1_1_quaternion" ],
          [ "Vector3", "classcom_1_1thalmic_1_1myo_1_1_vector3.html", "classcom_1_1thalmic_1_1myo_1_1_vector3" ],
          [ "XDirection", "enumcom_1_1thalmic_1_1myo_1_1_x_direction.html", "enumcom_1_1thalmic_1_1myo_1_1_x_direction" ]
        ] ]
      ] ]
    ] ]
];