var searchData=
[
  ['set',['set',['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a69cf4e89ac241b80144c054bb34f7ec5',1,'com.thalmic.myo.Quaternion.set()'],['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#a57f368202d7c54741bc2d71ffedba625',1,'com.thalmic.myo.Vector3.set()']]],
  ['setlockingpolicy',['setLockingPolicy',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#adb1633c644c16f54d8e8effec9fbf8f0',1,'com::thalmic::myo::Hub']]],
  ['setmyoattachallowance',['setMyoAttachAllowance',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#add2637b2598503002b3376090cddb797',1,'com::thalmic::myo::Hub']]],
  ['setsendusagedata',['setSendUsageData',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#ad35209eef6c1faf0a0bfcf27e429ed33',1,'com::thalmic::myo::Hub']]],
  ['shutdown',['shutdown',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#abcf3aa86d0d08d861d03f721b4de48e1',1,'com::thalmic::myo::Hub']]],
  ['subtract',['subtract',['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#ad4b7a8178603d8cccb4ec8ac06b9dd5b',1,'com::thalmic::myo::Vector3']]]
];
