var searchData=
[
  ['init',['init',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#a6630d2df92577e8e6c5c27673a6fc8ba',1,'com.thalmic.myo.Hub.init(Context context)'],['../classcom_1_1thalmic_1_1myo_1_1_hub.html#a91352ca197594c1cd447755d83d0b4e1',1,'com.thalmic.myo.Hub.init(Context context, String applicationIdentifier)']]],
  ['inverse',['inverse',['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#ae578877d7d4c63461f4bce1e7bb440a1',1,'com::thalmic::myo::Quaternion']]],
  ['isnotset',['isNotSet',['../classcom_1_1thalmic_1_1myo_1_1_firmware_version.html#a34c6689692f61c16beeef6960584ffd5',1,'com::thalmic::myo::FirmwareVersion']]],
  ['issendingusagedata',['isSendingUsageData',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#a8f56021d0e2657650176d94006ef594b',1,'com::thalmic::myo::Hub']]],
  ['isunlocked',['isUnlocked',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#a31dcdc4aa7bb0a60c22adab1b0ead025',1,'com::thalmic::myo::Myo']]]
];
