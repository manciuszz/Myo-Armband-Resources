var searchData=
[
  ['getarm',['getArm',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#a7d4571ae7022bfd15a58ab2d2f1a6926',1,'com::thalmic::myo::Myo']]],
  ['getconnecteddevices',['getConnectedDevices',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#a3c86161e09805b643969789d0a761861',1,'com::thalmic::myo::Hub']]],
  ['getfirmwareversion',['getFirmwareVersion',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#aead8053b6f93048970e04d314befef1f',1,'com::thalmic::myo::Myo']]],
  ['getlockingpolicy',['getLockingPolicy',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#a8caa26655706cd2412ab5a90dd55d839',1,'com::thalmic::myo::Hub']]],
  ['getmacaddress',['getMacAddress',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#aef5684d96174da12b25b91db597bc298',1,'com::thalmic::myo::Myo']]],
  ['getmyoattachallowance',['getMyoAttachAllowance',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#a91afe16d97aa296654fc41ecd28c5b0d',1,'com::thalmic::myo::Hub']]],
  ['getname',['getName',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#a122b6dbbaf1bdd32dfd8fb057c3ce198',1,'com::thalmic::myo::Myo']]],
  ['getpose',['getPose',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#a06bf72394a0bc8c67331b918d398fd7a',1,'com::thalmic::myo::Myo']]],
  ['getxdirection',['getXDirection',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#a313e6aa378b5bae9f24509e3f4f40f8d',1,'com::thalmic::myo::Myo']]]
];
