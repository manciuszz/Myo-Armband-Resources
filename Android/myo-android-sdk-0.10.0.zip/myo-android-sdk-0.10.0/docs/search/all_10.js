var searchData=
[
  ['unlock',['unlock',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#ab2b3998f4fddbbcbe2d24ab551c5b406',1,'com::thalmic::myo::Myo']]],
  ['unlocktype',['UnlockType',['../enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_unlock_type.html',1,'com::thalmic::myo::Myo']]]
];
