var searchData=
[
  ['multiply',['multiply',['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a235bcc2ae797a156969ce56d29bc5394',1,'com.thalmic.myo.Quaternion.multiply()'],['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#aa080de1887854ac414deeac1027c896b',1,'com.thalmic.myo.Vector3.multiply()']]],
  ['myo',['Myo',['../classcom_1_1thalmic_1_1myo_1_1_myo.html',1,'com::thalmic::myo']]]
];
