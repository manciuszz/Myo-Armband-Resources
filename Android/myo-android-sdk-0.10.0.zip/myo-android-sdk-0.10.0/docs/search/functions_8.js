var searchData=
[
  ['pitch',['pitch',['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#aaac1e063760b60fa9107b810b27d74e3',1,'com::thalmic::myo::Quaternion']]]
];
