var searchData=
[
  ['quaternion',['Quaternion',['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#afb17c372d8719279738b490f541469d9',1,'com.thalmic.myo.Quaternion.Quaternion()'],['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#ac0653fe3d6c36525c0502b86b3276075',1,'com.thalmic.myo.Quaternion.Quaternion(Quaternion other)'],['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a90139a4f3cf6acdb571364b2fc43be08',1,'com.thalmic.myo.Quaternion.Quaternion(double x, double y, double z, double w)']]]
];
