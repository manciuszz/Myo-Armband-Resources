var searchData=
[
  ['x',['x',['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#aa4784eecbb2dfbef14c773b68be254f7',1,'com.thalmic.myo.Quaternion.x()'],['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#add8b18664f7f7d5540d16dde1643ff57',1,'com.thalmic.myo.Vector3.x()']]]
];
