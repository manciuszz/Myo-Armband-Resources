var searchData=
[
  ['detach',['detach',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#a668d3d761b3d77826d6778dfd9bc9faa',1,'com::thalmic::myo::Hub']]],
  ['devicelistener',['DeviceListener',['../interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html',1,'com::thalmic::myo']]],
  ['divide',['divide',['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#ac66a7faf1dd489e721a9a04000a75c87',1,'com::thalmic::myo::Vector3']]],
  ['dot',['dot',['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#a78b22c0128fc4f4137a465ecd3ce9065',1,'com::thalmic::myo::Vector3']]]
];
