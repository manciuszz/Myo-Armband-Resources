var enumcom_1_1thalmic_1_1myo_1_1_arm =
[
    [ "LEFT", "enumcom_1_1thalmic_1_1myo_1_1_arm.html#a4275af85e1a826ddce6b9670d1a95426", null ],
    [ "RIGHT", "enumcom_1_1thalmic_1_1myo_1_1_arm.html#acd0ab4a4daf06267962939d12e36409b", null ],
    [ "UNKNOWN", "enumcom_1_1thalmic_1_1myo_1_1_arm.html#ab5cf9555171a9217ac71b880d48b0048", null ]
];