var enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_unlock_type =
[
    [ "HOLD", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_unlock_type.html#a3fed8a2365f45838ae6eb6cea48a67f6", null ],
    [ "TIMED", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_unlock_type.html#a0b5027c8876bfa2f985903133a18acdf", null ]
];