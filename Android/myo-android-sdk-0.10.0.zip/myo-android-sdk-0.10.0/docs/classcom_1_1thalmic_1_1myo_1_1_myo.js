var classcom_1_1thalmic_1_1myo_1_1_myo =
[
    [ "UnlockType", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_unlock_type.html", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_unlock_type" ],
    [ "VibrationType", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_vibration_type.html", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_vibration_type" ],
    [ "getArm", "classcom_1_1thalmic_1_1myo_1_1_myo.html#a7d4571ae7022bfd15a58ab2d2f1a6926", null ],
    [ "getFirmwareVersion", "classcom_1_1thalmic_1_1myo_1_1_myo.html#aead8053b6f93048970e04d314befef1f", null ],
    [ "getMacAddress", "classcom_1_1thalmic_1_1myo_1_1_myo.html#aef5684d96174da12b25b91db597bc298", null ],
    [ "getName", "classcom_1_1thalmic_1_1myo_1_1_myo.html#a122b6dbbaf1bdd32dfd8fb057c3ce198", null ],
    [ "getPose", "classcom_1_1thalmic_1_1myo_1_1_myo.html#a06bf72394a0bc8c67331b918d398fd7a", null ],
    [ "getXDirection", "classcom_1_1thalmic_1_1myo_1_1_myo.html#a313e6aa378b5bae9f24509e3f4f40f8d", null ],
    [ "isUnlocked", "classcom_1_1thalmic_1_1myo_1_1_myo.html#a31dcdc4aa7bb0a60c22adab1b0ead025", null ],
    [ "lock", "classcom_1_1thalmic_1_1myo_1_1_myo.html#a5f8acdbceaf3692e999c424467e1b6ca", null ],
    [ "notifyUserAction", "classcom_1_1thalmic_1_1myo_1_1_myo.html#a0a55afcd3074ee38181c714674e41318", null ],
    [ "requestRssi", "classcom_1_1thalmic_1_1myo_1_1_myo.html#aaa7ba8348b783b0c46e7a2d9b5407389", null ],
    [ "unlock", "classcom_1_1thalmic_1_1myo_1_1_myo.html#ab2b3998f4fddbbcbe2d24ab551c5b406", null ],
    [ "vibrate", "classcom_1_1thalmic_1_1myo_1_1_myo.html#a5223ccf9bf186862e851432964d3a89d", null ]
];